<?php
  $servername = "";
  $username = "";
  $password = "";
  $dbname = "ds122_2022_grr00000000";
?>
